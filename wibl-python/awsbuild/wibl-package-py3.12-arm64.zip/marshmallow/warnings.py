class Marshmallow4Warning(DeprecationWarning):
    pass


class ChangedInMarshmallow4Warning(Marshmallow4Warning):
    pass


class RemovedInMarshmallow4Warning(Marshmallow4Warning):
    pass
